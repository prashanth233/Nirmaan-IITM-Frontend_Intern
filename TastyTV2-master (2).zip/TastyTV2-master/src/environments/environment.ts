// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  // Your web app's Firebase configuration
  // Initialize Firebase
  firebaseConfig :{
    apiKey: "AIzaSyDfsNcd-DQna5nddAcLwu6_i-XeR3Nd6Aw",
    authDomain: "product-list-f7038.firebaseapp.com",
    databaseURL: "https://product-list-f7038.firebaseio.com",
    projectId: "product-list-f7038",
    storageBucket: "product-list-f7038.appspot.com",
    messagingSenderId: "48638874180",
    appId: "1:48638874180:web:0eabe932b8ec1f86846211",
    measurementId: "G-N34QYQE9DZ"
  }
};


  

  
  

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
